<?php
	session_start();
	include('includes/dbh.inc.php');
	include('product_functions.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home</title>
<meta charset="UTF-8">
<meta name="viewport" content="width = device - width, initial scale=1.0">
<meta name="author" content="Aaqil Modak">
<meta name="keywords" content="Nintendo, Nintendo Switch">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>



	<style type="text/css">
		@import url('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');

		.fade-in {
animation: fadeIn ease 1s;
-webkit-animation: fadeIn ease 1s;
-moz-animation: fadeIn ease 1s;
-o-animation: fadeIn ease 1s;
-ms-animation: fadeIn ease 1s;
}
@keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-moz-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-webkit-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-o-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-ms-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

    
     .navbar-brand{
            border: solid white;
            border-radius: 20px;
            
                  }
	*{
		margin: 0;
		padding: 0;
		color: #454545;
	}
	h1{
		width: 3%;
	    background-color: white;
	    top: 60px;
	    left: 90%;
	    cursor: pointer;
	    z-index: 4;
	    margin-right: 20px;
	    border-radius: 5px;
	    padding: 1px;
	}
	h1:before{
		content: attr(data-count);
	    color: white;
	    position: absolute;
	    right: 16px;
	    font-size: 15px;
	    text-align: center;
	    top: -12px;
	    width: 20px;
	    height: 20px;
	    background: red;
	    border-radius: 50%;
	    opacity: 0;
	}
	h1.zero:before{
		opacity: 1;
	}
		section{
			margin: 50px auto;
			width: 90%;
			height: 500px;
			display: flex;
			justify-content: space-around;
		}
		section div{
			width: 48%;
			height: 96%;
			background:#f5f5f5;
			padding: 1%;
			position: relative;
		}
		img{
			width: 525px;
			height: auto;
		}

		p{
			margin: 5px;
			font-weight: bold;
			font-size: 22px;
			
		}
		h6{
		    width: 50px;
		    padding: 5px;
		    margin: 10px;
		    font-size: 15px;
		}
		button{
			padding: 5px;
		    background: red;
		    border: none;
		    outline: none;
		    font-weight: bold;
		    color: #fafafa;
		    cursor: pointer;
		}

		button:hover{
	background: #b30000;
}
		section div span{
			position: absolute;
		    top: 14px;
		    left: 13px;
		    background: red;
		    width: 300px;
		    height: 186px;
		    display: none;
		}
		section div span img{
			width: 100%;
			height: 100%;
		}
		section div:nth-child(1)>span.active{
			animation: first 0.5s ease-in;
			z-index: 2;
			display: block;

		}
		section div:nth-child(2)>span.active{
			animation: second 0.5s ease-in;
			z-index: 2;
			display: block;

		}
		section div:nth-child(3)>span.active{
			animation: third 0.5s ease-in;
			z-index: 2;
			display: block;

		}
		section div:nth-child(4)>span.active{
			animation: four 0.5s ease-in;
			z-index: 2;
			display: block;

		}
		@keyframes first{
			to{
				width: 30px;
			    height: 20px;
			    left: 1290px;
			    top: -70px;
			}
		}
		@keyframes second{
			to{
				width: 30px;
			    height: 20px;
			    left: 948px;
			    top: -70px;
			}
		}
		@keyframes third{
			to{
				width: 30px;
			    height: 20px;
			    left: 606px;
			    top: -70px;
			}
		}
		@keyframes four{
			to{
				width: 30px;
			    height: 20px;
			    left: 265px;
			    top: -70px;
			}
		}


		
		.select{
			width: 60%;
			height: 580px;
			padding: 5%;
			background: #222;
			position: absolute;
			top: -1000px;
			left: 20%;
			transition: 0.5s;
			overflow-y: auto;
			margin: auto;
		}
		.select.display{
			top: 10px;
		}
		.select div{
			width: 100%;
			height: 200px;
			display: flex;
			padding: 5px;
			border: 1px solid white;
			position: relative;
			margin: 5px auto;
		}
		.select div img{
			width: 300px;
			height: 100%;
		}
		.select div p{
			padding: 35px;
			color: white;
		}
		.select div h6,
		.select div button{
			position: absolute;
			left: 45%;
			top: 50%;
			color: white;
		}
		.select div button{
			left: 60%;
			top: 55%;
		}
		.select div span{
			display: none;
		}

		#all{
			border: solid;
			margin-left: 40px;
			margin-right: 40px;
			border-bottom: 0px;
			border-top: 0px;
			border-right: 0px;
			border-left: 0px;
		}

		hr{
			background-color: red;
			height: 4px;
		}

		 @font-face{
    font-family: myFont;
    src: url(nintendofont-classic.ttf);
}

		#type{
			font-family: myFont;
			font-size: 30px;
			text-align: center;
			color: white;
		}

		#sub{

            border: solid red;
            border-radius: 30px;
            font-size: 20px;
            padding: 5px;
            background-color: white;
            font-family: myFont;
            font-size: 25px;
        }

		svg{
			color: white;
		}

		h4
		{
			padding: 10px;
			color: white;
		}

		.sticky {
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 2;
  opacity: 0.8;
}

.sticky + .content {
  padding-top: 60px;
}

#search{
	text-align: center;
	padding: 7px;
	border-radius: 10px;
	width: 125px;
	font-size: 20px;
}

#search:hover{
	background-color: #b30000;
}


		
	
	</style>
</head>


<body style="background-color: black" >
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  

    <a class="navbar-brand" href="#" style="padding: 5px;">Eshop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        
        <li class="nav-item">
          <a class="nav-link" href="#">
          	<?php 
          if (isset($_SESSION["useruid"]))
          	{	
          		echo "<a class='nav-link active' href='includes/logout.inc.php' style='font-size: 23px;'>Logout</a>";
          	}
          	?>
          		
          	</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#">
          	<a class="nav-link active" href="bot.php" style='font-size: 23px;'>
        
          	Chatbot
          		
          	</a>
        </li>
        
      </ul>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

      	<?php
		if (isset($_SESSION["useruid"]))
		{	
			echo "<p>Welcome, " . $_SESSION["useruid"] . "</p>";
		}
	?>

    </div>
  </div>
</nav>


<br><br><br>
	<button onclick="myFunction()" style="padding: 5px;">
	<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="white" class="bi bi-filter-square-fill" viewBox="0 0 16 16" >
  <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm.5 5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1 0-1zM4 8.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm2 3a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5z"/>
</svg> 
<a href="search.php" style="color: white;"> Search</a></button>
<br><br>

<?php
	getPro();
?>

	<section>
		<div class="item">
			<a href="">
        <img src="images/super-mario-3d-all-stars-switch-hero.jpg" alt="3D All Stars" id="shop">
        </a>
			<p>Super Mario 3D All Stars</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			 <a href="eshop-final-3D-World.php">    
        <img src="images/super-mario-3d-world-plus-bowsers-fury-switch-hero.jpg" alt="3D World + Bowser's Fury" id="shop">
        </a>
			<p>Super Mario 3D World + Bowser's Fury</p>
			<h6>$59.99</h6>
			<span></span>
			<br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/hyrule%20warriors.jpg" alt="Hyrule Warriors" id="shop">
    </a>
			<p>Hyrule Warriors: Age of Calamity</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			 <a href="">
        <img src="images/minecraft-dungeons-hero-edition-switch-hero.jpg" alt="Minecraft Dungeons" id="shop">
      </a>
			<p>Minecraft Dungeons</p>
			<h6>$29.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>


	<section>
		<div class="item">
			<a href="">
        <img src="images/paper-mario.jpg" alt="Paper Mario The Origami King" id="shop">
      </a>
			<p>Paper Mario The Origami King</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href="">
        <img src="images/animal-crossing-new-horizons.jpg" alt="Animal Crossing New Horizons" id="shop">
      </a>
			<p>Animal Crossing New Horizons</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/pokemon%20sw%20expansion.jpeg" alt="Pokemon Sword Expansion Pass" id="shop">
      </a>

			<p>Pokemon Sword Expansion Pass</p>
			<h6>$29.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<a href="">
        <img src="images/pokemon%20sh%20expansion.jpeg" alt="Pokemon Shield Expansion Pass" id="shop">
      </a>
			<p>Pokemon Shield Expansion Pass</p>
			<h6>$29.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			 <a href="">
        <img src="images/ni-no-kuni-wrath-of-the-white-witch-switch-hero.jpg" alt="Ni No Kuni Wrath of the White Witch" id="shop">
      </a>
			<p>Ni No Kuni Wrath of the White Witch</p>
			<h6><strike>$59.99</strike> $14.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			 <a href="">
        <img src="images/mario-tennis-aces-switch-hero.jpg" alt="Mario Tennis Aces" id="shop">
      </a>

			<p>Mario Tennis Aces</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">    
        <img src="images/avicii-invector-switch-hero.jpg" alt="AVICII Invector" id="shop">
      </a>
        
			<p>AVICII Invector</p>
			<h6>$19.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href="">
        <img src="images/dead-by-daylight-pic.jpg" alt="Dead By Daylight" id="shop">
      </a>
			<p>Dead By Daylight</p>
			<h6>$39.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

	</section>
<hr><br>

<a href="#contents">
<p id="type">Recent Releases</p>
</a>
	<section>
		<div class="item">
			<a href="">    
        <img src="images/avicii-invector-switch-hero.jpg" alt="AVICII Invector" id="shop">
      </a>
			<p>AVICII Invector</p>
			<h6>$19.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href=""> 
        <img src="images/2weistein.jpg" alt="2weistein - The Curse of the Red Dragon" id="shop">
      </a>
			<p>2weistein - The Curse of the Red Dragon</p>
			<h6>$18.00</h6>
			<span></span>
			<br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href=""> 
        <img src="images/active%20neurons2.jpg" alt="Active Neurons 2" id="shop">
      </a>
			<p>Active Neurons 2</p>
			<h6>$4.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<a href=""> 
        <img src="images/bounty%20battle.jpg" alt="Bounty Battle" id="shop">
      </a>
			<p>Bounty Battle</p>
			<h6><strike>$24.99</strike> $19.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>


	<section>
		<div class="item">
			<a href=""> 
        <img src="images/doodle-derby-switch-hero.jpg" alt="Doodle Derby" id="shop">
      </a>
			<p>Doodle Derby</p>
			<h6><strike>$7.99</strike> $6.39</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href=""> 
        <img src="images/drag-racing-rivals-switch-hero.jpg" alt="Drag Racing Rivals" id="shop">
      </a>
			<p>Drag Racing Rivals</p>
			<h6><strike>$9.99</strike> $7.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href=""> 
        <img src="images/Fight_Crab_Nintendo_Switch.jpg" alt="Fight Crab" id="shop">
      </a>


			<p>Fight Crab</p>
			<h6>$29.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<a href=""> 
        <img src="images/firework-switch-hero.jpg" alt="Firework" id="shop">
      </a>
			<p>Firework</p>
			<h6>$29.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

<hr><br>

<a href="#contents">
<p id="type">Great Deals </p>
</a>

<section>
		<div class="item">
			<a href="">
        <img src="images/dragon-ball-fighterz-switch-hero.jpg" alt="Dragonball FighterZ" id="shop">
        </a>

			<p>Dragonball FighterZ</p>
			<h6><strike>$59.99</strike> $9.59</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			 <a href="">
        <img src="images/little-nightmares-complete-edition-switch-hero.jpg" alt="Little Nightmares Complete Edition" id="shop">
      </a>
			<p>Little Nightmares Complete Edition</p>
			<h6><strike>$29.99</strike> $7.49</h6>
			<span></span>
			<br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/golf-zero-switch-hero.jpg" alt="Golf Zero" id="shop">
      </a>
			<p>Golf Zero</p>
			<h6><strike>$4.99</strike> $3.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			 <a href="">
        <img src="images/mana%20spark.jpg" alt="Mana Spark" id="shop">
      </a>
			<p>Mana Spark</p>
			<h6><strike>$9.99</strike> $0.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>


	<section>
		<div class="item">
			<a href="">
        <img src="images/mono.jpg" alt="Monopoly" id="shop">
      </a>
			<p>Monopoly</p>
			<h6><Strike>$39.99</Strike> $9.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href="">
        <img src="images/ni-no-kuni-wrath-of-the-white-witch-switch-hero.jpg" alt="Ni No Kuni Wrath of the White Witch" id="shop">
      </a>
			<p>Ni No Kuni Wrath of the White Witch</p>
			<h6><strike>$49.99</strike> $14.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			 <a href="">     
			  <img src="images/uno.jpg" alt="Uno" id="shop">
      </a>

			<p>Uno</p>
			<h6><strike>$9.99</strike> $3.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<a href="">
        <img src="images/bounty%20battle.jpg" alt="Bounty Battle" id="shop">
      </a>
			<p>Bounty Battle</p>
			<h6><strike>$24.99</strike> $19.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

<hr><br>




<a href="#contents">
<p id="type">Best-Sellers</p>
</a>

<section>
		<div class="item">
			 <a href="">
			 <img src="images/pokemon-sword-switch-hero.jpg" alt="Pokemon Sword" id="shop">
        </a>
			<p>Pokemon Sword</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			 <a href="">
         <img src="images/super-mario-3d-all-stars-switch-hero.jpg" alt="3D All Stars" id="shop">
        </a>
			<p>Super Mario 3D All Stars</p>
			<h6>$59.99</h6>
			<span></span>
			<br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/super-mario-odyssey-switch-hero.jpg" alt="Super Mario Odyssey" id="shop">
      </a>

			<p>Super Mario Odyssey</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			 <a href="">
        <img src="images/pokemon-shield-switch-hero.jpg" alt="Pokemon Shield" id="shop">
      </a>
			<p>Pokemon Shield</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>


	<section>
		<div class="item">
			 <a href="">
			 <img src="images/super-smash-bros-ultimate-switch-hero.jpg" alt="Super Smash Bros. Ultimate" id="shop">
      </a>

			<p>Super Smash Bros. Ultimate</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href="">
		 <img src="images/the-legend-of-zelda-breath-of-the-wild-switch-hero.jpg" alt="The Legend Of Zelda: Breath of the Wild" id="shop">
      </a>
        <br><br>
			<p>The Legend Of Zelda: Breath of the Wild</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/dragon-ball-fighterz-switch-hero.jpg" alt="Dragonball FighterZ" id="shop">
      </a>

			<p>Dragonball FighterZ</p>
			<h6><strike>$59.99</strike> $9.59</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<a href="">
        <img src="images/mario-kart-8-deluxe-switch-hero.jpg" alt="Mario Kart 8 Deluxe" id="shop">
      </a>
			<p>Mario Kart 8 Deluxe</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

<hr><br>

<a href="#contents">
<p id="type">Coming Soon</p>
</a>

<section>
		<div class="item">
			<a href="">
        <img src="images/super-mario-3d-world-plus-bowsers-fury-switch-hero.jpg" alt="3D World + Bowser's Fury" id="shop">
      </a>
			<p>Super Mario 3D World + Bowser's Fury</p>
			<h6>$59.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			 <a href="">
        <img src="images/hyrule%20warriors.jpg" alt="Hyrule Warriors: Age of Calamity" id="shop">
      </a>
			<p>Hyrule Warriors: Age of Calamity</p>
			<h6>$59.99</h6>
			<span></span>
			<br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/the-survivalists-switch-hero.jpg" alt="The Survivalists" id="shop">
      </a>
			<p>The Survivalists</p>
			<h6>$24.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			 <a href="">
			 <img src="images/fifa21.jpg" alt="FIFA 21 Nintendo Switch Legacy Edition" id="shop">
      </a>
			<p>FIFA 21 Nintendo Switch Legacy Edition</p>
			<h6>$49.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>


	<section>
		<div class="item">
			<a href="">
        <img src="images/unrailed.jpg" alt="Unrailed" id="shop">
      </a>
			<p>Unrailed</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<a href="">
        <img src="images/empire-of-sin.jpg" alt="Empire of Sin" id="shop">
      </a>
			<p>Empire of Sin</p>
			<h6>$39.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<a href="">
        <img src="images/nickelodeon-kart-racers-grand-prix-switch-hero.jpg" alt="Nickelodeon Kart Rcaers 2: Grand Prix" id="shop">
      </a>

			<p>Nickelodeon Kart Rcaers 2: Grand Prix</p>
			<h6><strike>$39.99</strike> $33.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			 <a href="">
        <img src="images/mini-motor-racing-x-switch-hero.jpg" alt="Mini Motor Racing X" id="shop">
      </a>
			<p>Mini Motor Racing X</p>
			<h6>$19.99</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

<hr><br>

<a href="#contents">
<p id="type">Nintendo Switch Online</p>
</a>
<br>
 <p style="font-size: 25px;" id="type"><b>What is Nintendo Switch Online?</b></p><br>
        <p style="font-size: 23px; color: white;">Nintendo Switch Online (colloquially known as NSO) is a suite of features on the Nintendo Switch video game console requiring purchase of a subscription. Nintendo Switch Online features include online multiplayer, cloud saving, voice chat, access to a library of Nintendo Entertainment System (NES) and Super Nintendo Entertainment System (SNES) games, as well as other promotions and offers. Following a period where some of its features were available to all users at no charge, the subscription service officially launched on September 18, 2018. <br><br>

The service is Nintendo's third generation online service after Nintendo Wi-Fi Connection and Nintendo Network.</p>

        <br><hr style="background-color: red; height: 2px;"><br><br><br>
        
        <p id="feat" style="font-size: 25px; text-align: center;" id="type"><b>Special Offers - These games are free to downlaod for Nintendo Switch Online Members!</b></p> <br><hr style="background-color: red; height: 2px;"><br>

<section>
		<div class="item">
			 <img src="images/tetris-99-switch-hero.jpg" alt="Tetris 99" id="shop">
			<p>Tetris 99</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			 <img src="images/nes.jpg" alt="NES - Online" id="shop">
			<p> Switch Online - Nintendo Entertainment System</p>
			<h6>Free Download</h6>
			<span></span>
			<br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<img src="images/snes.jpg" alt="SNES - Online" id="shop">
			<p> Switch Online - Super Nintendo Entertainment System</p>
			<h6>Free Download</h6>
			<span></span>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<img src="images/SM-35.jpg" alt="Super Mario 35" id="shop">
			<p>Super Mario Bros. 35</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>


	<section>
		<div class="item">
			<img src="images/100-gem-apples.jpg" alt="100 Gem Apples" id="shop">
			<p>100 Gem Apples DLC Pack</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>	
		</div>

		<div class="item">
			<img src="images/nook%20rug.jpg" alt="Animal Crossing New Horizons - Nook Rug" id="shop">
			<p>Animal Crossing New Horizons - Nook Rug</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>

	<section>
		<div class="item">
			<img src="images/pack%205.jpg" alt="Super Smash Bros. Ultimate - Pack 5" id="shop">

			<p>Super Smash Bros. Ultimate - DLC Pack 5</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>

		<div class="item">
			<img src="images/super-kirby-clash.jpg" alt="Super Kirby Clash" id="shop">
			<p>Super Kirby Clash</p>
			<h6>Free Download</h6>
			<span></span><br>
			<button>Add to Wishlist</button>
		</div>
	</section>



	


		
	</div>
</div>
	</div>

</body>
</html>