<?php
  session_start();
  include('includes/dbh.inc.php')
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search Page</title>
<meta charset="UTF-8">
<meta name="viewport" content="width = device - width, initial scale=1.0">
<meta name="author" content="Aaqil Modak">
<meta name="keywords" content="Nintendo, Nintendo Switch">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

	<style type="text/css">
		@import url('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');

		.fade-in {
animation: fadeIn ease 1s;
-webkit-animation: fadeIn ease 1s;
-moz-animation: fadeIn ease 1s;
-o-animation: fadeIn ease 1s;
-ms-animation: fadeIn ease 1s;
}
@keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-moz-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-webkit-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-o-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-ms-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

    
     .navbar-brand{
            border: solid white;
            border-radius: 20px;
            
                  }


     .sticky {
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 2;
}

.sticky + .content {
  padding-top: 60px;
}

@font-face{
    font-family: myFont;
    src: url(nintendofont-classic.ttf);
}

@font-face{
    font-family: myFont2;
    src: url(nintendofont2.ttf);
}

#myInput {
  background-image: url('images/search-icon.png'); 
  background-size: 2%;
  background-position: 7px 14px; 
  background-repeat: no-repeat; 
  width: 100%; 
  font-size: 16px; 
  padding: 12px 20px 12px 40px; 
  border: 1px solid #ddd; 
  margin-bottom: 12px; 
  font-family: myFont2;
  border-radius: 10px;
  font-size: 20px;
}

#myUL {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#myUL li a {
  border: 1px solid #ddd; 
  margin-top: -1px; 
  background-color: #f6f6f6; 
  padding: 12px; 
  text-decoration: none; 
  font-size: 18px; 
  color: black; 
  display: block; 
}

#myUL li a:hover:not(.header) {
  background-color: #eee; 
}

#list{
	font-weight: bold;
	font-size: 17px;
	
}

#all{
	margin-left: 50px;
	margin-right: 50px;
}

#sort{
	padding: 7px;
	background: red;
	color: white;
	font-family: myFont;
	font-weight: bold;
	width: 200px;
	text-align: center;
	border-radius: 20px;
	border: solid;
}

#sort:hover{
	background: #b30000;
}

svg{
	padding: 2px;
	color: white;
}

#icon{

	color: white;
	text-decoration: none;
	font-size: 19.5px;
}


		
	
	</style>
</head>

<body style="background-color: black;">
	<div class="fade-in">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  

    <a class="navbar-brand" href="#" style="padding: 5px;">Eshop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
       
        <li class="nav-item">
          <a class="nav-link" href="#">
            <?php 
          if (isset($_SESSION["useruid"]))
            { 
              echo "<a class='nav-link active' href='includes/logout.inc.php' style='font-size: 23px;'>Logout</a>";
            }
            ?></a>
        </li>
        <li class="nav-item">
          
        </li>
      </ul>

    </div>
  </div>
</nav>
  
         <br><br><br><br><br><br>


	<div id="all">

<a href="home.php" style="color: white;">
<span style="color: white;">Go Back</span></a>

<br><br>

<div class="form-group">
            <div class="col-md-6">
              <select name="prodCat" class="form-control">
                <option>
                  Search for a product...
                </option>

                <?php
                  $query = "SELECT * FROM product";
                  $run_query = mysqli_query($conn, $query);

                  while ($row = mysqli_fetch_array($run_query)) 
                  {
                    $p_id = $row['productID'];
                    $p_title = $row['productTitle'];

                    echo "<option value='$p_id'> $p_title </option>";
                  }
                ?>
              </select>

            </div>
          </div>
<!--
		<button onclick="sortList()" id="sort">Sort Alphabetically</button>
		<br><br>

		<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Games..">

<ul id="myUL">

  

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-SM3DAS.php">Super Mario 3D All Stars</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-3D%20World.php">Super Mario 3D World + Bowser's Fury</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-hyrule.php">Hyrule Warriors: Age of Calamity</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-mc%20dungeon.php">Minecraft Dungeons</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-paper%20mario.php">Paper Mario The Origami King</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-animal%20cross.php">Animal Crossing New Horizons</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-sword%20dlc.php">Pokemon Sword Expansion Pass</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-sword%20dlc.php">Pokemon Shield Expansion Pass</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-ni-no-kuni.php">Ni No Kuni Wrath of the White Witch</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-mario%20tennis.php">Mario Tennis Aces</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-avicii.php">AVICII Invector</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-dead-by-daylight.php">Dead By Daylight</a>
  </li>


  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-2weistein.php">2weistein - The Curse of the Red Dragon</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-active%20neurons2.php">Active Neurons 2</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-bounty%20battle.php">Bounty Battle</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-doodle%20derby.php">Doodle Derby</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-drag%20racing%20rivals.php">Drag Racing Rivals</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-fight%20crab.php">Fight Crab</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-firework.php">Firework</a>
  </li>



  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-dragonball.php">Dragonball FighterZ</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-little%20nightmares.php">Little Nightmares Complete Edition</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-golf%20zero.php">Golf Zero</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-mana%20spark.php">Mana Spark</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-monopoly.php">Monopoly</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-uno.php">Uno</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-bounty%20battle.php">Bounty Battle</a>
  </li>


  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-sword.php">Pokemon Sword</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-odyssey.php">Super Mario Odyssey</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-shield.php">Pokemon Shield</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-smash.php">Super Smash Bros. Ultimate</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-zelda.php">The Legend Of Zelda: Breath of the Wild</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-mariokart.php">Mario Kart 8 Deluxe</a>
  </li>



  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-survivalists.php">The Survivalists</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-fifa.php">FIFA 21 Nintendo Switch Legacy Edition</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-unrailed.php">Unrailed</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-empire-of-sin.php">Empire of Sin</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-kart-racers.php">Nickelodeon Kart Rcaers 2: Grand Prix</a>
  </li>

  <li id="list">
  	<a href="http://localhost/Sample/fwd/eshop-final-mini-moto.php">Mini Motor Racing X</a>
  </li>


  <li id="list">
  	<a href="#">Tetris 99</a>
  </li>

  <li id="list">
  	<a href="#">Switch Online - Nintendo Entertainment System (Nintendo Switch Online Mmebers Only!)</a>
  </li>

  <li id="list">
  	<a href="#">Switch Online - Super Nintendo Entertainment System (Nintendo Switch Online Mmebers Only!)</a>
  </li>

  <li id="list">
  	<a href="#">Super Mario Bros. 35</a>
  </li>

  <li id="list">
  	<a href="#">100 Gem Apples DLC Pack</a>
  </li>

  <li id="list">
  	<a href="#">Animal Crossing New Horizons - Nook Rug</a>
  </li>

  <li id="list">
  	<a href="#">Super Smash Bros. Ultimate - DLC Pack 5</a>
  </li>

  <li id="list">
  	<a href="#">Super Kirby Clash</a>
  </li>
</ul>

-->

	</div>
</div>
</body>
</html>

<script>
window.onscroll = function()
{
  myFunction()
};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

<script>
function myFunction() {
  
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = ul.getElementsByTagName('li');

  
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
</script>

<script>
function sortList() {
  var list, i, switching, b, shouldSwitch;
  list = document.getElementById("myUL");
  switching = true;

  while (switching) {
    
    switching = false;
    b = list.getElementsByTagName("LI");

    for (i = 0; i < (b.length - 1); i++) {
      
      shouldSwitch = false;
      
      if (b[i].innerHTML.toLowerCase() > b[i + 1].innerHTML.toLowerCase()) {
       
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      
      b[i].parentNode.insertBefore(b[i + 1], b[i]);
      switching = true;
    }
  }
}
</script>