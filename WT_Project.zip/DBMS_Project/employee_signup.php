<?php
	include("includes/dbh.inc.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale-1">

	<title>Employee Signup</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

	<style type="text/css">
		@import url('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
	</style>

</head>
<body>
	<div class="row">
	<div class="col-lg-12">
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-dashboard"></i> Employee Signup
			</li>
		</ol>
	</div>
</div>
<a href="admin-page.php" style="color: black;">	Go Back</a><br><br>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="fa fa-money fa-fw">
					</i> Enter Details
				</h3>
			</div>
			<div class="panel-body">
				<form method="post" class="form-horizontal" enctype="multipart/form-data">
					<div class="form-group">
						<label class="col-md-3 control-label">First Name</label>
						<div class="col-md-6">
							<input type="text" name="fname" class="form-control" required>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label">Last Name</label>
						<div class="col-md-6">
							<input type="text" name="lname" class="form-control" required>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label">Email</label>
						<div class="col-md-6">
							<input type="mail" name="email" class="form-control" required>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label">Password</label>
						<div class="col-md-6">
							<input type="password" name="pwd" class="form-control" required>
						</div>
					</div>

					

					<div class="form-group">
						<label class="col-md-3 control-label"> Department</label>
						<div class="col-md-6">
							<select name="dept" class="form-control">
								<option>
									Select a Department
								</option>

								<?php
									$query = "SELECT * FROM department";
									$run_query = mysqli_query($conn, $query);

									while ($row = mysqli_fetch_array($run_query)) 
									{
										$dept_id = $row['departmentID'];
										$dept_name = $row['departmentName'];

										echo "<option value='$dept_id'> $dept_name </option>";
									}
								?>
							</select>

						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> </label>
						<div class="col-md-6">
							<input type="submit" name="action" value="Submit" class="btn btn-primary form-control">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>

<?php
	if (isset($_POST['action']))
	{
		$firstname = $_POST['fname'];
		$lastname = $_POST['lname'];
		$email= $_POST['email'];
		$dept = $_POST['dept'];
		$passwd = $_POST['pwd'];

		$hashedPwd = password_hash($passwd, PASSWORD_DEFAULT);

		$sql = "INSERT INTO employee(employeeFirstName, employeeLastName, employeeEmail, employeePwd, employeeDept) VALUES('$firstname', '$lastname', '$email', '$hashedPwd', '$dept')";
		
		if ($conn->query($sql) === TRUE) 
		{
 			echo "New record created successfully";
		} 

		else 
		{
  			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		
	}
?>