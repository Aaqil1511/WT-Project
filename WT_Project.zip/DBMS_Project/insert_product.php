<?php
	include("includes/dbh.inc.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale-1">

	<title>Inserting Product</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

	<style type="text/css">
		@import url('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');


	</style>

	
	
</head>
<body>

<div class="row">
	<div class="col-lg-12">
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-dashboard"></i> Insert Products
			</li>
		</ol>
	</div>
</div>
<a href="admin-page.php" style="color: black;">	Go Back</a><br><br>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="fa fa-money fa-fw">
					</i> Insert Product
				</h3>
			</div>

			

			<div class="panel-body">
				<form method="post" class="form-horizontal" enctype="multipart/form-data">
					<div class="form-group">
						<label class="col-md-3 control-label"> Product Title</label>
						<div class="col-md-6">
							<input type="text" name="prodTitle" class="form-control" required>
						</div>
					</div>

					

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Category</label>
						<div class="col-md-6">
							<select name="prodCat" class="form-control" required>
								<option>
									Select a category
								</option>

								<?php
									$query = "SELECT * FROM productcategory";
									$run_query = mysqli_query($conn, $query);

									while ($row = mysqli_fetch_array($run_query)) 
									{
										$p_cat_id = $row['productCategoryID'];
										$p_cat_title = $row['productCategoryTitle'];

										echo "<option value='$p_cat_id'> $p_cat_title </option>";
									}
								?>
							</select>

						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label">Category</label>
						<div class="col-md-6">
							<select name="cat" class="form-control" required>
								<option>
									Select a category
								</option>

								<?php
									$query = "SELECT * FROM categories";
									$run_query = mysqli_query($conn, $query);

									while ($row = mysqli_fetch_array($run_query)) 
									{
										$cat_id = $row['categoryID'];
										$cat_title = $row['categoryTitle'];

										echo "<option value='$cat_id'> $cat_title </option>";
									}
								?>
							</select>

						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Image 1</label>
						<div class="col-md-6">
							<input type="file" name="prodImg1" class="form-control" >
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Image 2</label>
						<div class="col-md-6">
							<input type="file" name="prodImg2" class="form-control" >
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Image 3</label>
						<div class="col-md-6">
							<input type="file" name="prodImg3" class="form-control" >
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Price (in $)</label>
						<div class="col-md-6">
							<input type="text" name="prodPrice" class="form-control" required>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Keywords</label>
						<div class="col-md-6">
							<input type="text" name="prodKeywords" class="form-control" required>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> Product Description</label>
						<div class="col-md-6">
							<textarea class="form-control" name="prodDesc" cols="19" rows="6"></textarea>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-3 control-label"> </label>
						<div class="col-md-6">
							<input type="submit" name="action" value="Insert Product" class="btn btn-primary form-control">
						</div>
					</div>





				</form>
			</div>
		</div>
	</div>
</div>

<script src="js/tinymce/tinymce.min.js"></script>
<script>
		tinymce.init({ selector:'textarea'})
	</script>
</body>
</html>

<?php
	if ((isset($_POST['action'])))
	{
		$prod_Title = $_POST['prodTitle'];
		$prod_cat = $_POST['prodCat'];
		$category = $_POST['cat'];
		$prod_price = $_POST['prodPrice'];
		$prod_keywords = $_POST['prodKeywords'];
		$prod_desc = $_POST['prodDesc'];

		$prod_Img1 = $_FILES['prodImg1']['name'];
		$prod_Img2 = $_FILES['prodImg2']['name'];
		$prod_Img3 = $_FILES['prodImg3']['name'];

		$temp_name1 = $_FILES['prodImg1']['tmp_name'];
		$temp_name2 = $_FILES['prodImg2']['tmp_name'];
		$temp_name3 = $_FILES['prodImg3']['tmp_name'];

		move_uploaded_file($temp_name1, "images/$prod_Img1");
		move_uploaded_file($temp_name2, "images/$prod_Img2");
		move_uploaded_file($temp_name3, "images/$prod_Img3");

		$sql = "INSERT INTO product(productCategoryID, categoryID, dat, productTitle, productImg1, productImg2, productImg3, productPrice, productKeywords, productDesc) values ('$prod_cat', '$category', NOW(), '$prod_Title', '$prod_Img1', '$prod_Img2', '$prod_Img3', '$prod_price', '$prod_keywords', '$prod_desc')";

		if ($conn->query($sql) === TRUE) 
		{
 			echo "New record created successfully";
		} 

		else 
		{
  			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		/* $run_prod = mysqli_query($conn, $sql);
		if (!$run_prod)
		{
			echo "<script> alert('Product Inserted Successfully') </script>";
			echo "<script> window.open('insert_product.php','self') </script>";
		}

		else
		{
			echo "error";
		}

		*/
	}

?>