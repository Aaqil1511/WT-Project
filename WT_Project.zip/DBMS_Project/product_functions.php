<?php
	$db = mysqli_connect("localhost", "root", "", "dbms-project");
	function getPro()
	{
		global $db;

		$sql = "SELECT * FROM product order by 1 DESC LIMIT 0,8";
		$run = $db->query($sql);
		if ($run->num_rows > 0)
		{
			
		
		while ($row = $run->fetch_assoc())
		{
			$prodID = $row['productID'];
			$prodTitle = $row['productTitle'];
			$prodPrice = $row['productPrice'];
			$prodImg1 = $row['productImg1'];

			echo "<section>
						<div class='item'>
							<a href='eshop-final-3D-World?pro_id=$prodID'>
								<img class='img-responsive' src='images/$prodImg1'>
							</a>


								
									<p>
										
										$prodTitle
										
									<p>
									<h5>
										$ $prodPrice
									</h5>

									<br>

									<p class='button'>
										
								<button> Add to Cart </button
								
									</p>
							
						</div>
					</section>
				

				" ;
		}
	  }
	}
/*
	function getProdCat()
	{
		global $db;
		$sql = "SELECT * FROM productcategory";
		$run = $db->query($sql);
		if ($run->num_rows > 0)
		{
			
		
		while ($row = $run->fetch_assoc())
		{
			$prodCatID = $row['productCategoryID'];
			$prodCatTitle = $row['productCategoryTitle'];
			echo "<li>
					<a href='home.php?prodCat=$prodCatID'> $prodCatTitle </a>
				  </li>
				 ";
		}
		}
	}
*/
?>