<?php 

if (isset($_POST["submit"]))
{
	$username = $_POST["uid"];
	$passwd = $_POST["pass"];

	require_once 'dbh.inc.php';
	require_once 'functions.inc.php';

	if (emptyInputLogin($username, $passwd) !== false)
	{
		header("location: ../admin.php?error=emptyinput"); 
		exit();
	}

	loginUserAdmin($conn, $username, $passwd);	
}