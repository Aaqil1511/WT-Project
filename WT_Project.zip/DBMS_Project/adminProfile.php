<html>
<head>
</head>
<body>
<?php
	require_once 'includes/dbh.inc.php';

	if (isset($_GET['username']))
	{
		$username = $_GET['username'];
	}
	else die("Specify Username");
	$query = mysqli_query($conn, "SELECT * FROM users WHERE usersUid = '$username'");
	if (mysqli_num_rows($query) != 1) 
	{
		die("Invalid Username");
	}
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC))
	{
		$id = $row['usersID'];
		$name = $row['usersName'];
		$email = $row['usersEmail'];
		$uid = $row['usersUid'];
		$pwd = $row['usersPwd'];
	}
?>
<a href="admin-page.php" style="color: black;">	Go Back</a><br><br>
<h2><?php echo $uid; ?>'s Profile</h2><br>
<table>
	<tr>
		<td>
			ID:
		</td>
		<td>
			<?php echo $id; ?>
		</td>
	</tr>
	<tr>
		<td>
			Name:
		</td>
		<td>
			<?php echo $name; ?>
		</td>
	</tr>
	<tr>
		<td>
			Email:
		</td>
		<td>
			<?php echo $email; ?>
		</td>
	</tr>
	<tr>
		<td>
			Username:
		</td>
		<td>
			<?php echo $uid; ?>
		</td>
	</tr>
	<tr>
		<td>
			Password:
		</td>
		<td>
			<?php echo $pwd; ?>
		</td>
	</tr>
</table>
</body>
</html>
