<!DOCTYPE html>
<html lang="en">
<head>
    <title>Details</title>
	 <meta name="viewport" content="width = device - width, initial scale=1.0">
     <meta name="author" content="Aaqil Modak">
     <meta name="keywords" content="Nintendo, Nintendo Switch">
<head>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>

    <style>
      .fade-in {
animation: fadeIn ease 1s;
-webkit-animation: fadeIn ease 1s;
-moz-animation: fadeIn ease 1s;
-o-animation: fadeIn ease 1s;
-ms-animation: fadeIn ease 1s;
}
@keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-moz-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-webkit-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-o-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

@-ms-keyframes fadeIn {
0% {opacity:0;}
100% {opacity:1;}
}

        #left{

            height: auto;
            width: 1110px;
            border: solid;
            border-right: 0px;
            border-left: 0px;
            border-bottom: 0px;
            border-top: 0px; 
            position: relative;
            z-index: -1;
            float: left;
            background-color: #804000;
            padding: 10px;
        }

        #sm3das{

            color: white;
            font-size: 40px;
            margin-top: 20px; 
            margin-right: 20px;
        }

        #deets{

            margin-right: 20px;
            color: white;
            font-size: 20px;
        }

        img{

            height: auto;
            width: 50%;
        }

        #carouselExampleIndicators{

            background-color: #cc6600;
        }
      #right{
        border: solid;
        border-right: 0px;
        border-left: 0px;
        border-bottom: 0px;
        border-top: 0px; 
        height: 103.8%;
        text-align: right;
        padding: 15px;
        margin-left: 1110px;
        text-align: center;  
        position: absolute;
        z-index: 0;
        float: right;
        background-color: #994d00
      }

        #purch{

            border: solid;
            margin-left: 5px;
            padding: 4px;
            text-align: center;
        }

        #purch:hover{

            background-color: #006666;
            color: white;
            border: solid #4dc3ff;

        }


        #price{

            color: white;
            font-size: 40px;
            margin-top: 80px;
        }

        @font-face{
    font-family: myFont;
    src: url(nintendofont-classic.ttf);
}

        #sub{

            border: solid red;
            border-radius: 30px;
            font-size: 20px;
            padding: 5px;
            background-color: white;
            font-family: myFont;
            font-weight: bold;
        }

        #date{

             color: white;
             font-size: 20px;
        }


    </style>
    
</head>
<body>

    <div class="fade-in">
         
    
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
  

    <a class="navbar-brand" href="#" style="padding: 5px;">Eshop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#"><?php 
          if (isset($_SESSION["useruid"]))
            {    echo "<a class='nav-link active' href='profile.inc.php' style='font-size: 23px;'>Profile</a>";

            } 
            ?>
            
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <?php 
          if (isset($_SESSION["useruid"]))
            {   
                echo "<a class='nav-link active' href='includes/logout.inc.php' style='font-size: 23px;'>Logout</a>";
            }
            ?></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <?php 
          if (isset($_SESSION["useruid"]))
            {   
                echo "<a class='nav-link active' href='cart.php' style='font-size: 23px;'>Cart</a>";
            }
            ?></a>
        </li>
      </ul>
     

    </div>
  </div>
</nav>

    <div id="left">
        <p id="sm3das"><b>Super Mario 3D World + Bowser's Fury</b></p>

      


         <center>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/3D-WORLD-G1.jpg" alt="Super Mario 3D World + Bowser's Fury Gameplay">
    </div>

    <div class="carousel-item">
      <img src="images/3D-WORLD-G2.jpg" alt="Super Mario 3D World + Bowser's Fury Gameplay">
    </div>

    <div class="carousel-item">
      <img src="images/3D-WORLD-G3.jpg"  alt="Super Mario 3D World + Bowser's Fury Gameplay">
    </div>

    <div class="carousel-item">
      <img src="images/3D-WORLD-G4.jpg" alt="Super Mario 3D World + Bowser's Fury Gameplay">
    </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</center>

  <p id="deets">
    <span style="color: white; font-size: 23px; margin-left: 40px;"><b>The cat's out of the bag - Super Mario 3D World is coming to the Nintendo Switch system!</b></span> <br><br>

            Multiplayer mayhem pounces onto Nintendo Switch! This enhanced of Super Mario 3D World, which originally launched for the Wii U system, features co-op gameplay both online* and through local multiplayer in a variety of creative levels. Additional details about what new things this game has to offer will be revealed later. Super Mario 3D World + Bowser’s Fury launches for Nintendo Switch on Feb. 12, 2021. New amiibo figures Cat Mario and Cat Peach will also be released at the same time as the game.<br><br>



        </p>

    </div>
	<div id="right">
    <p id="price">
    
    <br><br>

    $59.99</p>
    <span style="color: white; background-color: #00ff00; padding: 10px; font-size: 25px; border-radius: 10px;">New</span>
    <br><br>
     <p id="date">Release Date: <br>
                   2/12/21
     </p> <br><br>

     <button id="purch">Click Here to Continue!</button>
    </div>
</div>
</body>
</html>