<!DOCTYPE HTML>
<html lang="en">
<meta name="viewport" content="width = device - width, initial scale=1.0">
<meta name="author" content="Aaqil Modak">
<meta name="keywords" content="Restaurant, Pubs, Food, Dining">

<head>
	<title>Signup</title>
 <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>

    <style>
    	html
{
	margin: 0;
	padding: 0;
	width: 100%;
	height: 100vh;
}
body
{
	margin: 0;
	text-align: center;
	padding: 0;
	width: 100%;
	height: 100vh;
	background: url(images/img1.jpg) 50% 50% no-repeat;
	background-size: cover;
	display: table;
}

.signme
{
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translateX(-50%) translateY(-50%);
}

h2
{
	font-family: Source Sans Pro;
	font-weight: lighter;
	color: #fff;
	font-size: 50px;
	text-align: center;
}

input
{
	display: block;
	width: 320px;
	height: 50px;
	background: rgba(0, 0, 0, 0.3)
	outline: none;
	border: 1px solid rgba(0, 0, 0, 0.5);
	font-family: Source Sans Pro;
	font-weight: lighter;
	font-size: 14px;
	margin-bottom: 10px;
	padding-left: 10px;
	border-radius: 5px;
}

button
{
	width: 332px;
	height: 58px;
	font-size: 16px;
	background: #000;
	font-weight: lighter;
	color: #fff;
	border: 0px;
	border-radius: 5px;
}

p{
	color: white;
    </style>
}
</head>
<body>
	<a href="index.php">Back |</a>
	<a href="login.php">Log In</a>
	<br><br>
	
	<h2>Sign Up Form</h2>
	<form action="includes/signup.inc.php" action="profile.inc.php" method="post">

		<center>
		<input type="text" name="name" placeholder="Enter Your Name" required><br>

		<input type="text" name="email" placeholder="Enter Your Email" required><br>

		<input type="text" name="uid" placeholder="Enter Your Username" required><br>

		<input type="password" name="pwd" placeholder="Enter Password" required><br>

		<input type="password" name="pwdrepeat" placeholder="Confirm Password" required><br>

		<button type="submit" name="submit">Sign Up!</button>

	</center>
	</form>

	<?php
	   if (isset($_GET["error"])) 
	   {
	   	  if ($_GET["error"] == "emptyInput")
	   	   {
	   		   	echo "<p>Fill All Fields</p>";
	   	   }

	   	   elseif ($_GET["error"] == "invaliduid") 
	   	     {
	   	   	 	echo "<p>Choose a proper username!</p>";
	   	   	 }

	   	   	 elseif ($_GET["error"] == "invalidemail")
	   	   	 {
	   	   	 	echo "<p>Choose  a proper email!</p>";
	   	   	 }	 

	   	   	 elseif ($_GET["error"] == "pwddontmatch")
	   	   	 {
	   	   	 	echo "<p>Passwords dont match!</p>";
	   	   	 }	 

	   	   	 elseif ($_GET["error"] == "usernametaken")
	   	   	 {
	   	   	 	echo "<p>This username has already been taken!</p>";
	   	   	 }	

	   	   	 elseif ($_GET["error"] == "stmtfailed")
	   	   	 {
	   	   	 	echo "<p>Something went wrong!</p>";
	   	   	 }	

	   	   	 elseif ($_GET["error"] == "none")
	   	   	 {
	   	   	 	echo "<p>Noice!</p>";
	   	   	 }	   	 
	   }
	?>

</body>
</html>